/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html"],
  theme: {
    fontFamily: {
      josefin: ["Josefin Sans", "sans-serif"],
      caveat: ["Josefin Sans", "sans-serif"],
    },
    extend: {},
  },
  plugins: [],
};
